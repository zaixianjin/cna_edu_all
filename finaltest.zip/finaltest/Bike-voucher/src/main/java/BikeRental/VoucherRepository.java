package BikeRental;

import org.springframework.data.repository.PagingAndSortingRepository;

public interface VoucherRepository extends PagingAndSortingRepository<Voucher, Long>{


}